<?php
if(isset($_GET['id'])){
    $qry = $conn->query("SELECT * FROM `student_list` where id = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        $res = $qry->fetch_array();
        foreach($res as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
    }
}
?>
<div class="content py-3">
    <div class="card card-outline card-primary shadow rounded-0">
        <div class="card-header">
            <h3 class="card-title"><b><?= isset($id) ? "Update Student Details - ". $roll : "New Student" ?></b></h3>
        </div>
        <div class="card-body">
            <div class="container-fluid">
                <form action="" id="student_form">
                <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
                    <fieldset class="border-bottom">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="roll" class="control-label">Badge Number</label>
                                <input type="text" name="roll" id="roll" autofocus value="<?= isset($roll) ? $roll : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
							<div class="form-group col-md-4">
                                <label for="rank" class="control-label">Rank</label>
                                <select name="rank" id="rank" value="<?= isset($rank) ? $rank : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Rank-</option>
									<option <?= isset($rank) && $rank == 'Civilian' ? 'selected' : '' ?>>Civilian</option>
									<option <?= isset($rank) && $rank == 'Police Captain' ? 'selected' : '' ?>>PCPT-Police Captain</option>
                                    <option <?= isset($rank) && $rank == 'Police Lieutenant' ? 'selected' : '' ?>>PLT-Police Lieutenant</option>
									<option <?= isset($rank) && $rank == 'Police Executive Master Sergeant' ? 'selected' : '' ?>>PEMS-Police Executive Master Sergeant</option>
                                    <option <?= isset($rank) && $rank == 'Police Chief Master Sergeant' ? 'selected' : '' ?>>PCMS-Police Chief Master Sergeant</option>
									<option <?= isset($rank) && $rank == 'Police Captain' ? 'selected' : '' ?>>PSMS-Police Senior Master Sergeant</option>
                                    <option <?= isset($rank) && $rank == 'Police Senior Master Sergeant' ? 'selected' : '' ?>>PMSg-Police Master Sergeant</option>
									<option <?= isset($rank) && $rank == 'Police Captain' ? 'selected' : '' ?>>PSSg-Police Staff Sergeant</option>
                                    <option <?= isset($rank) && $rank == 'Police Staff Sergeant' ? 'selected' : '' ?>>PCPL-Police Corporal</option>
									<option <?= isset($rank) && $rank == 'Pat-Patrolman' ? 'selected' : '' ?>>Pat-Patrolman/Patrolwoman</option>
									<option <?= isset($rank) && $rank == 'JSInsp.-Jail Senior Inspector' ? 'selected' : '' ?>>JSInsp.-Jail Senior Inspector</option>
									<option <?= isset($rank) && $rank == 'JInsp.-Jail Inspector' ? 'selected' : '' ?>>JInsp.-Jail Inspector</option>
									<option <?= isset($rank) && $rank == 'SJO4-Senior Jail Officer IV' ? 'selected' : '' ?>>SJO4-Senior Jail Officer IV</option>
                                    <option <?= isset($rank) && $rank == 'SJO3-Senior Jail Officer III' ? 'selected' : '' ?>>SJO3-Senior Jail Officer III</option>
									<option <?= isset($rank) && $rank == 'SJO2-Senior Jail Officer II' ? 'selected' : '' ?>>SJO2-Senior Jail Officer II</option>
                                    <option <?= isset($rank) && $rank == 'SJO1-Senior Jail Officer I' ? 'selected' : '' ?>>SJO1-Senior Jail Officer I</option>
									<option <?= isset($rank) && $rank == 'JO3-Jail Officer III' ? 'selected' : '' ?>>JO3-Jail Officer III</option>
                                    <option <?= isset($rank) && $rank == 'JO2-Jail Officer II' ? 'selected' : '' ?>>JO2-Jail Officer II</option>
									<option <?= isset($rank) && $rank == 'JO1-Jail Officer I' ? 'selected' : '' ?>>JO1-Jail Officer I</option>
                                    <option <?= isset($rank) && $rank == 'FSInsp.-Fire Senior Inspector' ? 'selected' : '' ?>>FSInsp.-Fire Senior Inspector</option>
									<option <?= isset($rank) && $rank == 'FInsp.-Fire Senior Inspector' ? 'selected' : '' ?>>FInsp.-Fire Inspector</option>
									<option <?= isset($rank) && $rank == 'SFO4-Senior Fire Officer IV' ? 'selected' : '' ?>>SFO4-Senior Fire Officer IV</option>
									<option <?= isset($rank) && $rank == 'SFO3-Senior Fire Officer III' ? 'selected' : '' ?>>SFO3-Senior Fire Officer III</option>
									<option <?= isset($rank) && $rank == 'SFO2-Senior Fire Officer II' ? 'selected' : '' ?>>SFO2-Senior Fire Officer II</option>
									<option <?= isset($rank) && $rank == 'SFO1-Senior Fire Officer I' ? 'selected' : '' ?>>SFO1-Senior Fire Officer I</option>
                                    <option <?= isset($rank) && $rank == 'FO3-Fire Officer III' ? 'selected' : '' ?>>FO3-Senior Fire Officer III</option>
									<option <?= isset($rank) && $rank == 'FO2-Fire Officer II' ? 'selected' : '' ?>>FO2-Senior Fire Officer II</option>
                                    <option <?= isset($rank) && $rank == 'FO1-Fire Officer I' ? 'selected' : '' ?>>FO1-Senior Fire Officer I</option>
                                    <option <?= isset($rank) && $rank == 'First Lieutenant (Army)' ? 'selected' : '' ?>>First Lieutenant (Army)</option>
									<option <?= isset($rank) && $rank == 'Second Lieutenant (Army)' ? 'selected' : '' ?>>Second Lieutenant (Army)</option>
                                    <option <?= isset($rank) && $rank == 'First Chief Master Sergeant (Army)' ? 'selected' : '' ?>>First Chief Master Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Chief Master Sergeant (Army)' ? 'selected' : '' ?>>Chief Master Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Senior Master Sergeant (Army)' ? 'selected' : '' ?>>Senior Master Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Master Sergeant (Army)' ? 'selected' : '' ?>>Master Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Technical Sergeant (Army)' ? 'selected' : '' ?>>Technical Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Staff Sergeant (Army)' ? 'selected' : '' ?>>Staff Sergeant (Army)</option>
                                    <option <?= isset($rank) && $rank == 'Sergeant (Army)' ? 'selected' : '' ?>>Sergeant (Army)</option>
									<option <?= isset($rank) && $rank == 'Corporal (Army)' ? 'selected' : '' ?>>Corporal (Army)</option>
                                    <option <?= isset($rank) && $rank == 'Private First Class (Army)' ? 'selected' : '' ?>>Private First Class (Army)</option>
									<option <?= isset($rank) && $rank == 'Captain (Navy)' ? 'selected' : '' ?>>Captain (Navy)</option>
                                    <option <?= isset($rank) && $rank == 'Commander(Navy)' ? 'selected' : '' ?>>Commander(Navy)</option>
									<option <?= isset($rank) && $rank == 'Lieutenant Commander(Navy)' ? 'selected' : '' ?>>Lieutenant Commander(Navy)</option>
                                    <option <?= isset($rank) && $rank == 'Lieutenant (senior grade)(Navy)' ? 'selected' : '' ?>>Lieutenant (senior grade)(Navy)</option>
									<option <?= isset($rank) && $rank == 'Lieutenant (junior grade)(Navy)' ? 'selected' : '' ?>>Lieutenant (junior grade)(Navy)</option>
									<option <?= isset($rank) && $rank == 'Ensign(Navy)' ? 'selected' : '' ?>>Ensign(Navy)</option>
									<option <?= isset($rank) && $rank == 'First Master Chief Petty Officer(Navy)' ? 'selected' : '' ?>>First Master Chief Petty Officer(Navy)</option>
                                    <option <?= isset($rank) && $rank == 'Master Chief Petty Officer(Navy)' ? 'selected' : '' ?>>Master Chief Petty Officer(Navy)</option>
									<option <?= isset($rank) && $rank == 'Senior Chief Petty Officer(Navy)' ? 'selected' : '' ?>>Senior Chief Petty Officer(Navy)</option>
                                    <option <?= isset($rank) && $rank == 'Chief Petty Officer(Navy)' ? 'selected' : '' ?>>Chief Petty Officer(Navy)</option>
									<option <?= isset($rank) && $rank == 'Petty Officer, 1st class(Navy)' ? 'selected' : '' ?>>Petty Officer, 1st class(Navy)</option>
									<option <?= isset($rank) && $rank == 'Petty Officer, 2nd class(Navy)' ? 'selected' : '' ?>>Petty Officer, 2nd class(Navy)</option>
									<option <?= isset($rank) && $rank == 'Petty Officer, 3rd class(Navy)' ? 'selected' : '' ?>>Petty Officer, 3rd class(Navy)</option>
									<option <?= isset($rank) && $rank == 'Seaman 2nd Class(Navy)' ? 'selected' : '' ?>>Seaman 2nd Class(Navy)</option>
									<option <?= isset($rank) && $rank == 'Seaman(Navy)' ? 'selected' : '' ?>>Seaman(Navy)</option>
									<option <?= isset($rank) && $rank == '(CAPT) CG - Captain' ? 'selected' : '' ?>>(CAPT) CG - Captain</option>
                                    <option <?= isset($rank) && $rank == '(CDR) CG - Commander' ? 'selected' : '' ?>>(CDR) CG - Commander</option>
									<option <?= isset($rank) && $rank == '(LCDR) CG - Lieutenant Commander' ? 'selected' : '' ?>>(LCDR) CG - Lieutenant Commander</option>
                                    <option <?= isset($rank) && $rank == '(LT) CG - Lieutenant' ? 'selected' : '' ?>>(LT) CG - Lieutenant</option>
									<option <?= isset($rank) && $rank == '(LTJG) CG - Lieutenant Junior Grade' ? 'selected' : '' ?>>(LTJG) CG - Lieutenant Junior Grade</option>
									<option <?= isset($rank) && $rank == '(ENS) CG - Ensign' ? 'selected' : '' ?>>(ENS) CG - Ensign</option>
									<option <?= isset($rank) && $rank == '(AUX1) CG - Auxiliarist First Class' ? 'selected' : '' ?>>(AUX1) CG - Auxiliarist First Class</option>
									<option <?= isset($rank) && $rank == '(AUX2) CG - Auxiliarist First Class' ? 'selected' : '' ?>>(AUX2) CG - Auxiliarist First Class</option>
									<option <?= isset($rank) && $rank == '(AUX3) CG - Auxiliarist First Class' ? 'selected' : '' ?>>(AUX3) CG - Auxiliarist First Class</option>
									<option <?= isset($rank) && $rank == '(AUX4) CG - Auxiliarist First Class' ? 'selected' : '' ?>>(AUX4) CG - Auxiliarist First Class</option>
                                </select>
                            </div>
							<div class="form-group col-md-4">
                                <label for="bos" class="control-label">Branch of Service</label>
                                <select name="bos" id="bos" value="<?= isset($bos) ? $bos : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Branch of Service-</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'PNP - Philippine National Police' ? 'selected' : '' ?>>PNP - Philippine National Police</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'BFP - Bureau of Fire and Protection' ? 'selected' : '' ?>>BFP - Bureau of Fire and Protection</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'BJMP - Bureau of Jail Management and Penology' ? 'selected' : '' ?>>BJMP - Bureau of Jail Management and Penology</option>
                                    <option <?= isset($branch_of_service) && $branch_of_service == 'AFP - Armed Forces of the Philippine' ? 'selected' : '' ?>>AFP - Armed Forces of the Philippine</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'NBI - National Bureau of Investigation' ? 'selected' : '' ?>>NBI - National Bureau of Investigation</option>
                                    <option <?= isset($branch_of_service) && $branch_of_service == 'PDEA - Philippine Drug Enforcement Agency' ? 'selected' : '' ?>>PDEA - Philippine Drug Enforcement Agency</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'SAF - Special Action Forces' ? 'selected' : '' ?>>SAF - Special Action Forces</option>
                                    <option <?= isset($branch_of_service) && $branch_of_service == 'CG - Coast Guard' ? 'selected' : '' ?>>CG - Coast Guard</option>
									<option <?= isset($branch_of_service) && $branch_of_service == 'Philippine Navy' ? 'selected' : '' ?>>Philippine Navy</option>
                                </select>
                            </div>
							<div class="form-group col-md-4">
                                <label for="unit" class="control-label">Unit Assignment</label>
                                <input type="text" name="unit" id="unit" value="<?= isset($unit) ? $unit : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="firstname" class="control-label">First Name</label>
                                <input type="text" name="firstname" id="firstname" value="<?= isset($firstname) ? $firstname : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="middlename" class="control-label">Middle Name</label>
                                <input type="text" name="middlename" id="middlename" value="<?= isset($middlename) ? $middlename : "" ?>" class="form-control form-control-sm rounded-0" placeholder='optional'>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="lastname" class="control-label">Last Name</label>
                                <input type="text" name="lastname" id="lastname" autofocus value="<?= isset($lastname) ? $lastname : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="gender" class="control-label">Gender</label>
                                <select name="gender" id="gender" value="<?= isset($gender) ? $gender : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option <?= isset($gender) && $gender == 'Male' ? 'selected' : '' ?>>Male</option>
                                    <option <?= isset($gender) && $gender == 'Female' ? 'selected' : '' ?>>Female</option>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="contact" class="control-label">Contact #</label>
                                <input type="text" name="contact" id="contact" value="<?= isset($contact) ? $contact : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
							 <div class="form-group col-md-4">
                                <label for="gmail" class="control-label">Email Account</label>
                                <input type="text" name="gmail" id="gmail" value="<?= isset($gmail) ? $gmail : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
                        </div>
						<div class="row">
						<div class="form-group col-md-4">
                                <label for="course" class="control-label">Course</label>
                                <select name="course" id="course" value="<?= isset($course) ? $course : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Course-</option>
									<option <?= isset($course) && $course == 'PS-IDC Public Safety Investigation and Detection Course' ? 'selected' : '' ?>>(CRIDEC) Crime Investigation and Detection Course</option>
                                    <option <?= isset($course) && $course == 'PS-TIC Public Safety Traffic Investigation Course' ? 'selected' : '' ?>>Specialization in  Traffic Investigation (CRIDEC)</option>
									<option <?= isset($course) && $course == 'PS-NIC Public Safety Narcotics Investigation Course' ? 'selected' : '' ?>>Specialization in Narcotics Investigation (CRIDEC)</option>
                                    <option <?= isset($course) && $course == 'DFIC Digital Forensic Investigation Course' ? 'selected' : '' ?>>(DFIC) Digital Forensic Investigation Course</option>
                                </select>
                        </div>
							<div class="form-group col-md-2">
                                <label for="class" class="control-label">Class</label>
                                <select name="class" id="class" value="<?= isset($class) ? $class : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Class-</option>
									<option <?= isset($class) && $class == '1980' ? 'selected' : '' ?>>1980</option>
                                    <option <?= isset($class) && $class == '1981' ? 'selected' : '' ?>>1981</option>
									<option <?= isset($class) && $class == '1982' ? 'selected' : '' ?>>1982</option>
                                    <option <?= isset($class) && $class == '1983' ? 'selected' : '' ?>>1983</option>
									<option <?= isset($class) && $class == '1984' ? 'selected' : '' ?>>1984</option>
                                    <option <?= isset($class) && $class == '1985' ? 'selected' : '' ?>>1985</option>
									<option <?= isset($class) && $class == '1986' ? 'selected' : '' ?>>1986</option>
                                    <option <?= isset($class) && $class == '1987' ? 'selected' : '' ?>>1987</option>
									<option <?= isset($class) && $class == '1988' ? 'selected' : '' ?>>1988</option>
                                    <option <?= isset($class) && $class == '1989' ? 'selected' : '' ?>>1989</option>
									<option <?= isset($class) && $class == '1990' ? 'selected' : '' ?>>1990</option>
                                    <option <?= isset($class) && $class == '1991' ? 'selected' : '' ?>>1991</option>
									<option <?= isset($class) && $class == '1992' ? 'selected' : '' ?>>1992</option>
                                    <option <?= isset($class) && $class == '1993' ? 'selected' : '' ?>>1993</option>
									<option <?= isset($class) && $class == '1994' ? 'selected' : '' ?>>1994</option>
                                    <option <?= isset($class) && $class == '1995' ? 'selected' : '' ?>>1995</option>
									<option <?= isset($class) && $class == '1996' ? 'selected' : '' ?>>1996</option>
                                    <option <?= isset($class) && $class == '1997' ? 'selected' : '' ?>>1997</option>
									<option <?= isset($class) && $class == '1998' ? 'selected' : '' ?>>1998</option>
                                    <option <?= isset($class) && $class == '1999' ? 'selected' : '' ?>>1999</option>
									<option <?= isset($class) && $class == '2000' ? 'selected' : '' ?>>2000</option>
                                    <option <?= isset($class) && $class == '2001' ? 'selected' : '' ?>>2001</option>
									<option <?= isset($class) && $class == '2002' ? 'selected' : '' ?>>2002</option>
                                    <option <?= isset($class) && $class == '2003' ? 'selected' : '' ?>>2003</option>
									<option <?= isset($class) && $class == '2004' ? 'selected' : '' ?>>2004</option>
                                    <option <?= isset($class) && $class == '2005' ? 'selected' : '' ?>>2005</option>
									<option <?= isset($class) && $class == '2006' ? 'selected' : '' ?>>2006</option>
                                    <option <?= isset($class) && $class == '2007' ? 'selected' : '' ?>>2007</option>
									<option <?= isset($class) && $class == '2008' ? 'selected' : '' ?>>2008</option>
                                    <option <?= isset($class) && $class == '2009' ? 'selected' : '' ?>>2009</option>
									<option <?= isset($class) && $class == '2010' ? 'selected' : '' ?>>2010</option>
                                    <option <?= isset($class) && $class == '2011' ? 'selected' : '' ?>>2011</option>
									<option <?= isset($class) && $class == '2012' ? 'selected' : '' ?>>2012</option>
                                    <option <?= isset($class) && $class == '2013' ? 'selected' : '' ?>>2013</option>
									<option <?= isset($class) && $class == '2014' ? 'selected' : '' ?>>2014</option>
                                    <option <?= isset($class) && $class == '2015' ? 'selected' : '' ?>>2015</option>
									<option <?= isset($class) && $class == '2016' ? 'selected' : '' ?>>2016</option>
                                    <option <?= isset($class) && $class == '2017' ? 'selected' : '' ?>>2017</option>
									<option <?= isset($class) && $class == '2018' ? 'selected' : '' ?>>2018</option>
                                    <option <?= isset($class) && $class == '2019' ? 'selected' : '' ?>>2019</option>
									<option <?= isset($class) && $class == '2020' ? 'selected' : '' ?>>2020</option>
                                    <option <?= isset($class) && $class == '2021' ? 'selected' : '' ?>>2021</option>
									<option <?= isset($class) && $class == '2022' ? 'selected' : '' ?>>2022</option>
                                    <option <?= isset($class) && $class == '2023' ? 'selected' : '' ?>>2023</option>
									<option <?= isset($class) && $class == '2024' ? 'selected' : '' ?>>2024</option>
                                    <option <?= isset($class) && $class == '2025' ? 'selected' : '' ?>>2025</option>
									<option <?= isset($class) && $class == '2026' ? 'selected' : '' ?>>2026</option>
                                    <option <?= isset($class) && $class == '2027' ? 'selected' : '' ?>>2027</option>
									<option <?= isset($class) && $class == '2028' ? 'selected' : '' ?>>2028</option>
                                    <option <?= isset($class) && $class == '2029' ? 'selected' : '' ?>>2029</option>
									<option <?= isset($class) && $class == '2030' ? 'selected' : '' ?>>2030</option>
                                    <option <?= isset($class) && $class == '2031' ? 'selected' : '' ?>>2031</option>
									<option <?= isset($class) && $class == '2032' ? 'selected' : '' ?>>2032</option>
                                    <option <?= isset($class) && $class == '2033' ? 'selected' : '' ?>>2033</option>
									<option <?= isset($class) && $class == '2034' ? 'selected' : '' ?>>2034</option>
                                    <option <?= isset($class) && $class == '2035' ? 'selected' : '' ?>>2035</option>
									<option <?= isset($class) && $class == '2036' ? 'selected' : '' ?>>2036</option>
                                    <option <?= isset($class) && $class == '2037' ? 'selected' : '' ?>>2037</option>
									<option <?= isset($class) && $class == '2038' ? 'selected' : '' ?>>2038</option>
                                    <option <?= isset($class) && $class == '2039' ? 'selected' : '' ?>>2039</option>
									<option <?= isset($class) && $class == '2040' ? 'selected' : '' ?>>2040</option>
                                    <option <?= isset($class) && $class == '2041' ? 'selected' : '' ?>>2041</option>
									<option <?= isset($class) && $class == '2042' ? 'selected' : '' ?>>2042</option>
                                    <option <?= isset($class) && $class == '2043' ? 'selected' : '' ?>>2043</option>
									<option <?= isset($class) && $class == '2044' ? 'selected' : '' ?>>2044</option>
                                    <option <?= isset($class) && $class == '2045' ? 'selected' : '' ?>>2045</option>
									<option <?= isset($class) && $class == '2046' ? 'selected' : '' ?>>2046</option>
                                    <option <?= isset($class) && $class == '2047' ? 'selected' : '' ?>>2047</option>
									<option <?= isset($class) && $class == '2048' ? 'selected' : '' ?>>2048</option>
                                    <option <?= isset($class) && $class == '2049' ? 'selected' : '' ?>>2049</option>
									<option <?= isset($class) && $class == '2050' ? 'selected' : '' ?>>2050</option>
                                    <option <?= isset($class) && $class == '2051' ? 'selected' : '' ?>>2051</option>
									<option <?= isset($class) && $class == '2052' ? 'selected' : '' ?>>2052</option>
                                    <option <?= isset($class) && $class == '2053' ? 'selected' : '' ?>>2053</option>
									<option <?= isset($class) && $class == '2054' ? 'selected' : '' ?>>2054</option>
                                    <option <?= isset($class) && $class == '2055' ? 'selected' : '' ?>>2055</option>
									<option <?= isset($class) && $class == '2056' ? 'selected' : '' ?>>2056</option>
                                    <option <?= isset($class) && $class == '2057' ? 'selected' : '' ?>>2057</option>
									<option <?= isset($class) && $class == '2058' ? 'selected' : '' ?>>2058</option>
                                    <option <?= isset($class) && $class == '2059' ? 'selected' : '' ?>>2059</option>
									<option <?= isset($class) && $class == '2060' ? 'selected' : '' ?>>2060</option>
                                    <option <?= isset($class) && $class == '2061' ? 'selected' : '' ?>>2061</option>
									<option <?= isset($class) && $class == '2062' ? 'selected' : '' ?>>2062</option>
                                    <option <?= isset($class) && $class == '2063' ? 'selected' : '' ?>>2063</option>
									<option <?= isset($class) && $class == '2064' ? 'selected' : '' ?>>2064</option>
                                    <option <?= isset($class) && $class == '2065' ? 'selected' : '' ?>>2065</option>
									<option <?= isset($class) && $class == '2066' ? 'selected' : '' ?>>2066</option>
                                    <option <?= isset($class) && $class == '2067' ? 'selected' : '' ?>>2067</option>
									<option <?= isset($class) && $class == '2068' ? 'selected' : '' ?>>2068</option>
                                    <option <?= isset($class) && $class == '2069' ? 'selected' : '' ?>>2069</option>
									<option <?= isset($class) && $class == '2070' ? 'selected' : '' ?>>2070</option>
                                    <option <?= isset($class) && $class == '2071' ? 'selected' : '' ?>>2071</option>
									<option <?= isset($class) && $class == '2072' ? 'selected' : '' ?>>2072</option>
                                    <option <?= isset($class) && $class == '2073' ? 'selected' : '' ?>>2073</option>
									<option <?= isset($class) && $class == '2074' ? 'selected' : '' ?>>2074</option>
                                    <option <?= isset($class) && $class == '2075' ? 'selected' : '' ?>>2075</option>
									<option <?= isset($class) && $class == '2076' ? 'selected' : '' ?>>2076</option>
                                    <option <?= isset($class) && $class == '2077' ? 'selected' : '' ?>>2077</option>
									<option <?= isset($class) && $class == '2078' ? 'selected' : '' ?>>2078</option>
                                    <option <?= isset($class) && $class == '2079' ? 'selected' : '' ?>>2079</option>
									<option <?= isset($class) && $class == '2080' ? 'selected' : '' ?>>2080</option>
                                    <option <?= isset($class) && $class == '2081' ? 'selected' : '' ?>>2081</option>
									<option <?= isset($class) && $class == '2082' ? 'selected' : '' ?>>2082</option>
                                    <option <?= isset($class) && $class == '2083' ? 'selected' : '' ?>>2083</option>
									<option <?= isset($class) && $class == '2084' ? 'selected' : '' ?>>2084</option>
                                    <option <?= isset($class) && $class == '2085' ? 'selected' : '' ?>>2085</option>
									<option <?= isset($class) && $class == '2086' ? 'selected' : '' ?>>2086</option>
                                    <option <?= isset($class) && $class == '2087' ? 'selected' : '' ?>>2087</option>
									<option <?= isset($class) && $class == '2088' ? 'selected' : '' ?>>2088</option>
                                    <option <?= isset($class) && $class == '2089' ? 'selected' : '' ?>>2089</option>
									<option <?= isset($class) && $class == '1990' ? 'selected' : '' ?>>2090</option>
                                    <option <?= isset($class) && $class == '1991' ? 'selected' : '' ?>>2091</option>
									<option <?= isset($class) && $class == '1992' ? 'selected' : '' ?>>2092</option>
                                    <option <?= isset($class) && $class == '1993' ? 'selected' : '' ?>>2093</option>
									<option <?= isset($class) && $class == '1994' ? 'selected' : '' ?>>2094</option>
                                    <option <?= isset($class) && $class == '1995' ? 'selected' : '' ?>>2095</option>
									<option <?= isset($class) && $class == '1996' ? 'selected' : '' ?>>2096</option>
                                    <option <?= isset($class) && $class == '1997' ? 'selected' : '' ?>>2097</option>
									<option <?= isset($class) && $class == '1998' ? 'selected' : '' ?>>2098</option>
                                    <option <?= isset($class) && $class == '1999' ? 'selected' : '' ?>>2099</option>
									<option <?= isset($class) && $class == '2100' ? 'selected' : '' ?>>2100</option>
                                    <option <?= isset($class) && $class == '2101' ? 'selected' : '' ?>>2101</option>
									<option <?= isset($class) && $class == '2102' ? 'selected' : '' ?>>2102</option>
                                    <option <?= isset($class) && $class == '2103' ? 'selected' : '' ?>>2103</option>
									<option <?= isset($class) && $class == '2104' ? 'selected' : '' ?>>2104</option>
                                    <option <?= isset($class) && $class == '2105' ? 'selected' : '' ?>>2105</option>
									<option <?= isset($class) && $class == '2106' ? 'selected' : '' ?>>2106</option>
                                    <option <?= isset($class) && $class == '2107' ? 'selected' : '' ?>>2107</option>
									<option <?= isset($class) && $class == '2108' ? 'selected' : '' ?>>2108</option>
                                    <option <?= isset($class) && $class == '2109' ? 'selected' : '' ?>>2109</option>
									<option <?= isset($class) && $class == '2110' ? 'selected' : '' ?>>2110</option>
                                    <option <?= isset($class) && $class == '2111' ? 'selected' : '' ?>>2111</option>
									<option <?= isset($class) && $class == '2112' ? 'selected' : '' ?>>2112</option>
                                    <option <?= isset($class) && $class == '2113' ? 'selected' : '' ?>>2113</option>
									<option <?= isset($class) && $class == '2114' ? 'selected' : '' ?>>2114</option>
                                    <option <?= isset($class) && $class == '2115' ? 'selected' : '' ?>>2115</option>
									<option <?= isset($class) && $class == '2116' ? 'selected' : '' ?>>2116</option>
                                    <option <?= isset($class) && $class == '2117' ? 'selected' : '' ?>>2117</option>
									<option <?= isset($class) && $class == '2118' ? 'selected' : '' ?>>2118</option>
                                    <option <?= isset($class) && $class == '2119' ? 'selected' : '' ?>>2119</option>
									<option <?= isset($class) && $class == '2120' ? 'selected' : '' ?>>2120</option>
                                    <option <?= isset($class) && $class == '2121' ? 'selected' : '' ?>>2121</option>
									<option <?= isset($class) && $class == '2122' ? 'selected' : '' ?>>2122</option>
                                    <option <?= isset($class) && $class == '2123' ? 'selected' : '' ?>>2123</option>
									<option <?= isset($class) && $class == '2124' ? 'selected' : '' ?>>2124</option>
                                    <option <?= isset($class) && $class == '2125' ? 'selected' : '' ?>>2125</option>
									<option <?= isset($class) && $class == '2126' ? 'selected' : '' ?>>2126</option>
                                    <option <?= isset($class) && $class == '2127' ? 'selected' : '' ?>>2127</option>
									<option <?= isset($class) && $class == '2128' ? 'selected' : '' ?>>2128</option>
                                    <option <?= isset($class) && $class == '2129' ? 'selected' : '' ?>>2129</option>
									<option <?= isset($class) && $class == '2130' ? 'selected' : '' ?>>2130</option>
                                    <option <?= isset($class) && $class == '2131' ? 'selected' : '' ?>>2131</option>
									<option <?= isset($class) && $class == '2132' ? 'selected' : '' ?>>2132</option>
                                    <option <?= isset($class) && $class == '2133' ? 'selected' : '' ?>>2133</option>
									<option <?= isset($class) && $class == '2134' ? 'selected' : '' ?>>2134</option>
                                    <option <?= isset($class) && $class == '2135' ? 'selected' : '' ?>>2135</option>
									<option <?= isset($class) && $class == '2136' ? 'selected' : '' ?>>2136</option>
                                    <option <?= isset($class) && $class == '2137' ? 'selected' : '' ?>>2137</option>
									<option <?= isset($class) && $class == '2138' ? 'selected' : '' ?>>2138</option>
                                    <option <?= isset($class) && $class == '2139' ? 'selected' : '' ?>>2139</option>
									<option <?= isset($class) && $class == '2140' ? 'selected' : '' ?>>2140</option>
                                    <option <?= isset($class) && $class == '2141' ? 'selected' : '' ?>>2141</option>
									<option <?= isset($class) && $class == '2142' ? 'selected' : '' ?>>2142</option>
                                    <option <?= isset($class) && $class == '2143' ? 'selected' : '' ?>>2143</option>
									<option <?= isset($class) && $class == '2144' ? 'selected' : '' ?>>2144</option>
                                    <option <?= isset($class) && $class == '2145' ? 'selected' : '' ?>>2145</option>
									<option <?= isset($class) && $class == '2146' ? 'selected' : '' ?>>2146</option>
                                    <option <?= isset($class) && $class == '2147' ? 'selected' : '' ?>>2147</option>
									<option <?= isset($class) && $class == '2148' ? 'selected' : '' ?>>2148</option>
                                    <option <?= isset($class) && $class == '2149' ? 'selected' : '' ?>>2149</option>
									<option <?= isset($class) && $class == '2150' ? 'selected' : '' ?>>2150</option>
                                    <option <?= isset($class) && $class == '2151' ? 'selected' : '' ?>>2151</option>
									<option <?= isset($class) && $class == '2152' ? 'selected' : '' ?>>2152</option>
                                    <option <?= isset($class) && $class == '2153' ? 'selected' : '' ?>>2153</option>
									<option <?= isset($class) && $class == '2154' ? 'selected' : '' ?>>2154</option>
                                    <option <?= isset($class) && $class == '2155' ? 'selected' : '' ?>>2155</option>
									<option <?= isset($class) && $class == '2156' ? 'selected' : '' ?>>2156</option>
                                    <option <?= isset($class) && $class == '2157' ? 'selected' : '' ?>>2157</option>
									<option <?= isset($class) && $class == '2158' ? 'selected' : '' ?>>2158</option>
                                    <option <?= isset($class) && $class == '2159' ? 'selected' : '' ?>>2159</option>
									<option <?= isset($class) && $class == '2160' ? 'selected' : '' ?>>2160</option>
                                    <option <?= isset($class) && $class == '2161' ? 'selected' : '' ?>>2161</option>
									<option <?= isset($class) && $class == '2162' ? 'selected' : '' ?>>2162</option>
                                    <option <?= isset($class) && $class == '2163' ? 'selected' : '' ?>>2163</option>
									<option <?= isset($class) && $class == '2164' ? 'selected' : '' ?>>2164</option>
                                    <option <?= isset($class) && $class == '2165' ? 'selected' : '' ?>>2165</option>
									<option <?= isset($class) && $class == '2166' ? 'selected' : '' ?>>2166</option>
                                    <option <?= isset($class) && $class == '2167' ? 'selected' : '' ?>>2167</option>
									<option <?= isset($class) && $class == '2168' ? 'selected' : '' ?>>2168</option>
                                    <option <?= isset($class) && $class == '2169' ? 'selected' : '' ?>>2169</option>
									<option <?= isset($class) && $class == '2170' ? 'selected' : '' ?>>2170</option>
                                    <option <?= isset($class) && $class == '2171' ? 'selected' : '' ?>>2171</option>
									<option <?= isset($class) && $class == '2172' ? 'selected' : '' ?>>2172</option>
                                    <option <?= isset($class) && $class == '2173' ? 'selected' : '' ?>>2173</option>
									<option <?= isset($class) && $class == '2174' ? 'selected' : '' ?>>2174</option>
                                    <option <?= isset($class) && $class == '2175' ? 'selected' : '' ?>>2175</option>
									<option <?= isset($class) && $class == '2176' ? 'selected' : '' ?>>2176</option>
                                    <option <?= isset($class) && $class == '2177' ? 'selected' : '' ?>>2177</option>
									<option <?= isset($class) && $class == '2178' ? 'selected' : '' ?>>2178</option>
                                    <option <?= isset($class) && $class == '2179' ? 'selected' : '' ?>>2179</option>
									<option <?= isset($class) && $class == '2180' ? 'selected' : '' ?>>2180</option>
                                    <option <?= isset($class) && $class == '2181' ? 'selected' : '' ?>>2181</option>
									<option <?= isset($class) && $class == '2182' ? 'selected' : '' ?>>2182</option>
                                    <option <?= isset($class) && $class == '2183' ? 'selected' : '' ?>>2183</option>
									<option <?= isset($class) && $class == '2184' ? 'selected' : '' ?>>2184</option>
                                    <option <?= isset($class) && $class == '2185' ? 'selected' : '' ?>>2185</option>
									<option <?= isset($class) && $class == '2186' ? 'selected' : '' ?>>2186</option>
                                    <option <?= isset($class) && $class == '2187' ? 'selected' : '' ?>>2187</option>
									<option <?= isset($class) && $class == '2188' ? 'selected' : '' ?>>2188</option>
                                    <option <?= isset($class) && $class == '2189' ? 'selected' : '' ?>>2189</option>
									<option <?= isset($class) && $class == '2190' ? 'selected' : '' ?>>2190</option>
                                    <option <?= isset($class) && $class == '2191' ? 'selected' : '' ?>>2191</option>
									<option <?= isset($class) && $class == '2192' ? 'selected' : '' ?>>2192</option>
                                    <option <?= isset($class) && $class == '2193' ? 'selected' : '' ?>>2193</option>
									<option <?= isset($class) && $class == '2194' ? 'selected' : '' ?>>2194</option>
                                    <option <?= isset($class) && $class == '2195' ? 'selected' : '' ?>>2195</option>
									<option <?= isset($class) && $class == '2196' ? 'selected' : '' ?>>2196</option>
                                    <option <?= isset($class) && $class == '2197' ? 'selected' : '' ?>>2197</option>
									<option <?= isset($class) && $class == '2198' ? 'selected' : '' ?>>2198</option>
                                    <option <?= isset($class) && $class == '2199' ? 'selected' : '' ?>>2199</option>
									<option <?= isset($class) && $class == '2200' ? 'selected' : '' ?>>2200</option>
                                </select>
						    </div>
						<div class="form-group col-md-2">
                                <label for="batch" class="control-label">Batch</label>
                                <select name="batch" id="batch" value="<?= isset($batch) ? $batch : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Batch-</option>
									<option <?= isset($batch) && $batch == '01' ? 'selected' : '' ?>>-01</option>
                                    <option <?= isset($batch) && $batch == '02' ? 'selected' : '' ?>>-02</option>
									<option <?= isset($batch) && $batch == '03' ? 'selected' : '' ?>>-03</option>
                                    <option <?= isset($batch) && $batch == '04' ? 'selected' : '' ?>>-04</option>
									<option <?= isset($batch) && $batch == '05' ? 'selected' : '' ?>>-05</option>
                                </select>
                        </div>
							<div class="form-group col-md-2">
                                <label for="company" class="control-label">Company</label>
                                <select name="company" id="company" value="<?= isset($company) ? $company : "" ?>" class="form-control form-control-sm rounded-0" required>
                                    <option>-Select Company-</option>
									<option <?= isset($company) && $company == 'TRAFFIC Specialization' ? 'selected' : '' ?>>TRAFFIC Specialization</option>
									<option <?= isset($company) && $company == 'NARCOTICS Specialization' ? 'selected' : '' ?>>NARCOTICS Specialization</option>
									<option <?= isset($company) && $company == 'ALPHA' ? 'selected' : '' ?>>ALPHA</option>
                                    <option <?= isset($company) && $company == 'BRAVO' ? 'selected' : '' ?>>BRAVO</option>
									<option <?= isset($company) && $company == 'CHARLIE' ? 'selected' : '' ?>>CHARLIE</option>
                                    <option <?= isset($company) && $company == 'DELTA' ? 'selected' : '' ?>>DELTA</option>
									<option <?= isset($company) && $company == 'ECHO' ? 'selected' : '' ?>>ECHO</option>
									<option <?= isset($company) && $company == 'FOXTROT' ? 'selected' : '' ?>>FOXTROT</option>
                                    <option <?= isset($company) && $company == 'GOLF' ? 'selected' : '' ?>>GOLF</option>
									<option <?= isset($company) && $company == 'HOTEL' ? 'selected' : '' ?>>HOTEL</option>
                                    <option <?= isset($company) && $company == 'INDIA' ? 'selected' : '' ?>>INDIA</option>
									<option <?= isset($company) && $company == 'JULIETT' ? 'selected' : '' ?>>JULIETT</option>
									<option <?= isset($company) && $company == 'KILO' ? 'selected' : '' ?>>KILO</option>
                                    <option <?= isset($company) && $company == 'LIMA' ? 'selected' : '' ?>>LIMA</option>
									<option <?= isset($company) && $company == 'MIKE' ? 'selected' : '' ?>>MIKE</option>
                                    <option <?= isset($company) && $company == 'NOVEMBER' ? 'selected' : '' ?>>NOVEMBER</option>
									<option <?= isset($company) && $company == 'OSCAR' ? 'selected' : '' ?>>OSCAR</option>
									<option <?= isset($company) && $company == 'PAPA' ? 'selected' : '' ?>>PAPA</option>
                                    <option <?= isset($company) && $company == 'QUEBEC' ? 'selected' : '' ?>>QUEBEC</option>
									<option <?= isset($company) && $company == 'ROMEO' ? 'selected' : '' ?>>ROMEO</option>
									<option <?= isset($company) && $company == 'SIERRA' ? 'selected' : '' ?>>SIERRA</option>
                                    <option <?= isset($company) && $company == 'TANGO' ? 'selected' : '' ?>>TANGO</option>
									<option <?= isset($company) && $company == 'UNIFORM' ? 'selected' : '' ?>>UNIFORM</option>
                                    <option <?= isset($company) && $company == 'VICTOR' ? 'selected' : '' ?>>VICTOR</option>
									<option <?= isset($company) && $company == 'WHISKEY' ? 'selected' : '' ?>>WHISKEY</option>
									<option <?= isset($company) && $company == 'X-RAY' ? 'selected' : '' ?>>X-RAY</option>
                                    <option <?= isset($company) && $company == 'YANKEE' ? 'selected' : '' ?>>YANKEE</option>
									<option <?= isset($company) && $company == 'ZULU' ? 'selected' : '' ?>>ZULU</option>
                                </select>
						</div>
							<div class="row">
								<div class="form-group col-md-6">
									<label for="dob" class="control-label">Date Taken</label>
									<input type="date" name="dob" id="dob" value="<?= isset($dob) ? $dob : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
							<div class="form-group col-md-6">
									<label for="gd" class="control-label">Graduation Date</label>
									<input type="date" name="gd" id="gd" value="<?= isset($gd) ? $gd : "" ?>" class="form-control form-control-sm rounded-0" required>
                            </div>
							</div>
                      <!--  <div class="row">
                            <div class="form-group col-md-12">
                                <label for="present_address" class="control-label">Present Address</label>
                                <textarea rows="3" name="present_address" id="present_address" class="form-control form-control-sm rounded-0" required><?= isset($present_address) ? $present_address : "" ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="permanent_address" class="control-label">Permanent Address</label>
                                <textarea rows="3" name="permanent_address" id="permanent_address" class="form-control form-control-sm rounded-0" required><?= isset($permanent_address) ? $permanent_address : "" ?></textarea>
                            </div>
                        </div>-->
                    </fieldset>
                </form>
            </div>
        </div>
        <div class="card-footer text-right">
            <button class="btn btn-flat btn-primary btn-sm" type="submit" form="student_form">Save Student Details</button>
            <a href="./?page=students" class="btn btn-flat btn-default border btn-sm">Cancel</a>
        </div>
    </div>
</div>
<script>
    $(function(){
        $('#student_form').submit(function(e){
            e.preventDefault();
            var _this = $(this)
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_student",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
                success:function(resp){
                    if(resp.status == 'success'){
                        location.href="./?page=students/view_student&id="+resp.sid;
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reason.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    $('html,body,.modal').animate({scrollTop:0},'fast')
                    end_loader();
                }
            })
        })
    })
</script>